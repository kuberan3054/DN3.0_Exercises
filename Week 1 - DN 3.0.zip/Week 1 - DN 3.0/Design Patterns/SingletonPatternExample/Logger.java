public class Logger{
    //private static instance of the class
    private static Logger instance;
    //private consturctor
    private Logger(){}
    //public static method to get instance of logger class
    public static Logger getInstance(){
        if(instance == null){
            instance=new Logger();
        }
        return instance;
    }

}
// Creating a test class to verify that only one instance of Logger is created.
class SingletonTestClass{
    public static void main(String args[]){
        Logger obj1=Logger.getInstance();
        Logger obj2=Logger.getInstance();

        if(obj1 == obj2){
            System.out.println("Both Logger instances are the same.");
        }
        else{
            System.out.println("Both Logger instances are not the same.");
        }
    }
}