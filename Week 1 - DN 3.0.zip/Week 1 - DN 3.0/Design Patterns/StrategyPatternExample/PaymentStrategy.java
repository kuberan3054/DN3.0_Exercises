//strategy interface
public interface PaymentStrategy {
    void pay(double amount);
}
//classes that implement paymentstrategy class
class CreditCardPayment implements PaymentStrategy {
    private String cardNumber;
    private String cardHolderName;

    public CreditCardPayment(String cardNumber, String cardHolderName) {
        this.cardNumber = cardNumber;
        this.cardHolderName = cardHolderName;
    }

    public void pay(double amount) {
        System.out.println(amount + " paid using Credit Card. Card Number: " + cardNumber);
    }
}

class PayPalPayment implements PaymentStrategy {
    private String email;

    public PayPalPayment(String email) {
        this.email = email;
    }

    public void pay(double amount) {
        System.out.println(amount + " paid using PayPal. Email: " + email);
    }
}
//context class
class PaymentContext {
    private PaymentStrategy paymentStrategy;

    public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    public void pay(double amount) {
        if (paymentStrategy != null) {
            paymentStrategy.pay(amount);
        } else {
            System.out.println("No payment strategy selected.");
        }
    }
}
//test class
class StrategyPatternExample {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        // Using Credit Card Payment
        context.setPaymentStrategy(new CreditCardPayment("1234-5678-9876-5432", "John Doe"));
        context.pay(150.00);
        System.out.println();

        // Using PayPal Payment
        context.setPaymentStrategy(new PayPalPayment("johndoe@example.com"));
        context.pay(75.00);
        System.out.println();

        // No payment strategy selected
        context.setPaymentStrategy(null);
        context.pay(200.00);
    }
}
