//defining a interface
public interface Document{
    void open();
}
//concrete classes for each doc typr
class wordDocument implements Document{
    public void open(){
        System.out.println("Opening a word document.");
    }
}
class pdfDocument implements Document{
    public void open(){
        System.out.println("Opening a PDF document.");
    }
}
class excelDocument implements Document{
    public void open(){
        System.out.println("Opening a Excel document.");
    }
}
//Create an abstract class DocumentFactory with a method createDocument().
abstract class DocumentFactory{
    //this method is intended to return a instance of Document or subclass
    public abstract Document createDocument();

}
//Create concrete factory classes for each document type that extends DocumentFactory and implements the createDocument() method.
class wordDoc extends DocumentFactory{
    public Document createDocument(){
        //override
        return new wordDocument();
    }
}
class pdfDoc extends DocumentFactory{
    public Document createDocument(){
        return new pdfDocument();
    }
}
class excelDoc extends DocumentFactory{
    public Document createDocument(){
        return new excelDocument();
    }
}
//testing factory method
class factoryTest{
    public static void main(String args[]){
        DocumentFactory obj1=new wordDoc();
        Document wordDocument=obj1.createDocument();
        wordDocument.open();

        DocumentFactory obj2=new pdfDoc();
        Document pdfDocument=obj2.createDocument();
        pdfDocument.open();

        DocumentFactory obj3=new excelDoc();
        Document excelDocument=obj3.createDocument();
        excelDocument.open();
    }
    
}