// component interface
public interface Notifier {
    void send(String message);
}
// EmailNotifier class
class EmailNotifier implements Notifier {
    public void send(String message) {
        System.out.println("Sending email with message: " + message);
    }
}
 // decorator class
abstract class NotifierDecorator implements Notifier {
    protected Notifier wrappedNotifier;

    public NotifierDecorator(Notifier notifier) {
        this.wrappedNotifier = notifier;
    }

    public void send(String message) {
        wrappedNotifier.send(message);
    }
}
// SMSNotifierDecorator
class SMSNotifierDecorator extends NotifierDecorator {
    public SMSNotifierDecorator(Notifier notifier) {
        super(notifier);
    }

    public void send(String message) {
        super.send(message);
        sendSMS(message);
    }

    private void sendSMS(String message) {
        System.out.println("Sending SMS with message: " + message);
    }
}
// SlackNotifierDecorator
class SlackNotifierDecorator extends NotifierDecorator {
    public SlackNotifierDecorator(Notifier notifier) {
        super(notifier);
    }

    
    public void send(String message) {
        super.send(message);
        sendSlackMessage(message);
    }

    private void sendSlackMessage(String message) {
        System.out.println("Sending Slack message with message: " + message);
    }
}
// test class
class NotificationTest {
    public static void main(String[] args) {
        // Base notifier - Email
        Notifier emailNotifier = new EmailNotifier();

        // Email + SMS
        Notifier emailAndSMSNotifier = new SMSNotifierDecorator(emailNotifier);

        // Email + SMS + Slack
        Notifier allChannelsNotifier = new SlackNotifierDecorator(emailAndSMSNotifier);

        // Sending notifications
        System.out.println("Sending notification using Email:");
        emailNotifier.send("This is a test message.");

        System.out.println("\nSending notification using Email and SMS:");
        emailAndSMSNotifier.send("This is a test message.");

        System.out.println("\nSending notification using Email, SMS, and Slack:");
        allChannelsNotifier.send("This is a test message.");
    }
}



