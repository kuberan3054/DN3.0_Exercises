//subject interface
public interface Image {
    void display();
}
//real subject class
class RealImage implements Image {
    private String fileName;

    public RealImage(String fileName) {
        this.fileName = fileName;
        loadFromDisk(fileName);
    }
    private void loadFromDisk(String fileName) {
        System.out.println("Loading " + fileName);
        //loads an image from a remote server
    }
    public void display() {
        System.out.println("Displaying " + fileName);
    }
}
//proxy class
class ProxyImage implements Image {
    private RealImage realImage;
    private String fileName;

    public ProxyImage(String fileName) {
        this.fileName = fileName;
    }    
    public void display() {
        if (realImage == null) {
            realImage = new RealImage(fileName); // Lazy initialization
        }
        realImage.display();
    }
}
//test class
class ProxyPatternExample {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("image1.jpg");
        Image image2 = new ProxyImage("image2.jpg");

        // Image will be loaded from disk
        image1.display();
        System.out.println("");

        // Image will not be loaded from disk again, cached version will be displayed
        image1.display();
        System.out.println("");

        // New image will be loaded from disk
        image2.display();
        System.out.println("");

        // Cached version of image2 will be displayed
        image2.display();
    }
}
