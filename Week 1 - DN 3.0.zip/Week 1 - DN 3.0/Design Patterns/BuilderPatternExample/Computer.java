public class Computer{
    private String CPU;
    private String RAM;
    private String storage;
    //private constructor with builder as parameter
    private Computer(Builder builder){
        this.CPU=builder.CPU;
        this.RAM=builder.RAM;
        this.storage=builder.storage;
    }

    public String toString(){
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + ", Storage=" + storage + "]";
    }
    static class Builder{
        private String CPU;
        private String RAM;
        private String storage;

        public Builder(String CPU, String RAM, String storage){
            this.CPU=CPU;
            this.RAM=RAM;
            this.storage=storage;
        }
        //build methos to create the computer instance
        public Computer build(){
            return new Computer(this);
        }
    }
    
}
class BuilderTest{
    public static void main(String args[]) {
        Computer basic=new Computer.Builder("i5","8gb","1tb").build();
        Computer highend=new Computer.Builder("i7","32gb","2tb").build();
        System.out.println(basic);
        System.out.println(highend);
    }
}