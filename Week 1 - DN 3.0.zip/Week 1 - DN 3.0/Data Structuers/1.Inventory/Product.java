import java.util.*;
public class Product{
    int productId;
    int quantity;
    String productName;
    int price;

    public Product(int productId, int quantity, String productName,int price){
        this.productId=productId;
        this.productName=productName;
        this.quantity=quantity;
        this.price=price;
    }
    public String toString(){
        return "Product ID: " + productId + ", Name: " + productName +
               ", Quantity: " + quantity + ", Price: " + price;
    }
}
class InventoryManager{
private HashMap<Integer, Product> inventory;

    public InventoryManager() {
        this.inventory = new HashMap<>();
    }

    public void addProduct(Product product) {
        inventory.put(product.productId, product);
        System.out.println("Product added successfully.");
    }

    public void updateProduct(int productId, Product updatedProduct) {
        if (inventory.containsKey(productId)) {
            inventory.put(productId, updatedProduct);
            System.out.println("Product updated successfully.");
        } else {
            System.out.println("Product not found.");
        }
    }

    public void deleteProduct(int productId) {
        if (inventory.containsKey(productId)) {
            inventory.remove(productId);
            System.out.println("Product removed successfully.");
        } else {
            System.out.println("Product not found.");
        }
    }

    public void displayProduct(int productId) {
        Product product = inventory.get(productId);
        if (product != null) {
            System.out.println(product);
        } else {
            System.out.println("Product not found.");
        }
    }

    public void displayAllProducts() {
        if (inventory.isEmpty()) {
            System.out.println("No products in inventory.");
        } else {
            for (Product product : inventory.values()) {
                System.out.println(product);
            }
        }
    }
}

class InventoryManagementSystem {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nInventory Management System");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. Display Product");
            System.out.println("5. Display All Products");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Product ID: ");
                    int addId = sc.nextInt();
                    sc.nextLine(); // Consume newline
                    System.out.print("Enter Product Name: ");
                    String addName = sc.nextLine();
                    System.out.print("Enter Quantity: ");
                    int addQty = sc.nextInt();
                    System.out.print("Enter Price: ");
                    int addPrice = sc.nextInt();
                    Product addProduct = new Product(addId, addQty, addName, addPrice);
                    manager.addProduct(addProduct);
                    break;

                case 2:
                    System.out.print("Enter Product ID to update: ");
                    int updateId = sc.nextInt();
                    sc.nextLine(); // Consume newline
                    System.out.print("Enter New Product Name: ");
                    String updateName = sc.nextLine();
                    System.out.print("Enter New Quantity: ");
                    int updateQty = sc.nextInt();
                    System.out.print("Enter New Price: ");
                    int updatePrice = sc.nextInt();
                    Product updateProduct = new Product(updateId, updateQty, updateName, updatePrice);
                    manager.updateProduct(updateId, updateProduct);
                    break;

                case 3:
                    System.out.print("Enter Product ID to delete: ");
                    int deleteId = sc.nextInt();
                    manager.deleteProduct(deleteId);
                    break;

                case 4:
                    System.out.print("Enter Product ID to display: ");
                    int displayId = sc.nextInt();
                    manager.displayProduct(displayId);
                    break;

                case 5:
                    manager.displayAllProducts();
                    break;

                case 6:
                    System.out.println("Exiting...");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}