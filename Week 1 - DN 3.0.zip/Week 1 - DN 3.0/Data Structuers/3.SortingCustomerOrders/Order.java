public class Order {
    int orderId;
    String customerName;
    int totalPrice;

    public Order(int orderId, String customerName, int totalPrice) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.totalPrice = totalPrice;
    }

    @Override
    public String toString() {
        return "OrderID: " + orderId + ", Customer name: " + customerName + ", Total Price: " + totalPrice;
    }
}

class SortExample {
    public static void main(String[] args) {
        Order[] orders = {
            new Order(1, "A", 200),
            new Order(2, "B", 50),
            new Order(3, "C", 100),
            new Order(4, "D", 75)
        };

        // Bubble Sort
        System.out.println("Bubble Sort:");
        bubbleSortByTotalPrice(orders);
        for (Order order : orders) {
            System.out.println(order);
        }

        // Resetting the orders array for Quick Sort demonstration
        orders = new Order[]{
            new Order(1, "A", 200),
            new Order(2, "B", 50),
            new Order(3, "C", 100),
            new Order(4, "D", 75)
        };

        // Quick Sort
        System.out.println("Quick Sort:");
        quickSortByTotalPrice(orders, 0, orders.length - 1);
        for (Order order : orders) {
            System.out.println(order);
        }
    }

    public static void bubbleSortByTotalPrice(Order[] array) {
        int n = array.length;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (array[j].totalPrice > array[j + 1].totalPrice) {
                    // Swap array[j] and array[j+1]
                    Order temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swapped = true;
                }
            }
            if (!swapped) break;
        }
    }

    public static void quickSortByTotalPrice(Order[] array, int low, int high) {
        if (low < high) {
            int pi = partition(array, low, high);

            quickSortByTotalPrice(array, low, pi - 1);
            quickSortByTotalPrice(array, pi + 1, high);
        }
    }

    private static int partition(Order[] array, int low, int high) {
        int pivot = array[high].totalPrice;
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (array[j].totalPrice <= pivot) {
                i++;

                // Swap array[i] and array[j]
                Order temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }

        // Swap array[i+1] and array[high] (or pivot)
        Order temp = array[i + 1];
        array[i + 1] = array[high];
        array[high] = temp;

        return i + 1;
    }
}
