import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class EmployeeBase {
    private HashMap<Integer, String> employeeMap = new HashMap<>();

    public void addEmployee() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter Employee ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Enter Employee Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Employee Position: ");
        String position = scanner.nextLine();

        Employee employee = new Employee(id, name, position);
        employeeMap.put(id, employee.toString());
    }

    public void deleteEmployee(int empId) {
        employeeMap.remove(empId);
    }

    public void traverse() {
        for (Map.Entry<Integer, String> entry : employeeMap.entrySet()) {
            System.out.println(entry.getValue());
        }
    }

    public String search(int empId) {
        return employeeMap.getOrDefault(empId, "Employee not found");
    }

    public static void main(String[] args) {
        EmployeeBase employeeBase = new EmployeeBase();

        employeeBase.addEmployee();
        employeeBase.addEmployee();
        
        employeeBase.deleteEmployee(123);
        System.out.println(employeeBase.search(101));
        
        employeeBase.traverse();
    }
}

class Employee {
    private int empId;
    private String empName;
    private String empPosition;

    public Employee(int empId, String empName, String empPosition) {
        this.empId = empId;
        this.empName = empName;
        this.empPosition = empPosition;
    }

    @Override
    public String toString() {
        return "Employee ID: " + empId +
               "\nEmployee Name: " + empName +
               "\nEmployee Position: " + empPosition +
               "\n------------------------";
    }
}
