package com.library.repository;

public class BookRepository {
    public void displayRepositoryInfo() {
        System.out.println("BookRepository is successfully injected into BookService.");
    }
}